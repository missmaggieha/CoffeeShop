package com.BTP.coffeeshop;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CoffeeActivity extends Activity {
	
	private Socket clientSocket;
	private DataOutputStream dosToServer;
	@SuppressWarnings("unused")
	private DataInputStream disFromServer;
	private ObjectInputStream ois;
	private InputStream is;
	private String[][] read;
	private String[] names;
	private String[] type;
	private String[] description;
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_coffee);
		// Show the Up button in the action bar.
		setupActionBar();
		
		
		
		
		new OpenConnectionTask().execute();
		HandleConnectionTask task = (HandleConnectionTask) new HandleConnectionTask().execute();	
		try {
			task.get(5000, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			names = new String[read.length];
			type = new String[read.length];
			description = new String[read.length];
			for(int i = 0; i< read.length ; i++){
				names[i] = read[i][1];
				type[i] = read[i][0];
				description[i] = read[i][2];
			}
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 
		        android.R.layout.simple_list_item_1, names);
		ListView listView = (ListView) findViewById(R.id.listView1);
		listView.setAdapter(adapter);
		
		

		listView.setOnItemClickListener(new OnItemClickListener() {
			  @Override
			  public void onItemClick(AdapterView<?> parent, View view,
			    int position, long id) {
//			    Toast.makeText(getApplicationContext(),
//			      "Click ListItem Number " + position, Toast.LENGTH_LONG)
//			      .show();
				  Intent intent = new Intent(CoffeeActivity.this, Details.class);
				  intent.putExtra("id", position);
				  intent.putExtra("name", names);
				  intent.putExtra("desc", description);
				  intent.putExtra("type", type);
				  
				  CoffeeActivity.this.startActivity(intent);
			  }
			}); 
		
	}

	private class OpenConnectionTask extends AsyncTask <Void, Void, Void> {
		
		@Override
		protected Void doInBackground(Void... arg0) {
			
			try {
				clientSocket = new Socket( InetAddress.getByName("10.0.2.2"), 8000);
				
				// connect input and output streams to the socket
				dosToServer = new DataOutputStream( clientSocket.getOutputStream() );
				disFromServer = new DataInputStream( clientSocket.getInputStream() );
				
				is = clientSocket.getInputStream();
				ois = new ObjectInputStream(is);
				
				System.out.println(" Connected. ");
			}
			catch( Exception ex1 ){ }
			
			return null;
			
		}
		
	}	// end OpenConnectionTask method
	
	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.coffee, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	// Create a message handling object as an anonymous class.
	private class HandleConnectionTask extends AsyncTask <String[][], Void, String[][]> {

		@Override
		protected String[][] doInBackground( String[][]... arg0 ) {
			
			try {
				dosToServer.writeUTF("coffee");
				dosToServer.flush();
				
				
				
				try {
					read = (String[][])ois.readObject();
					for( int j = 0 ; j < read.length ; j ++ ) {
	    	    		for( int i = 0; i < read[j].length; i++ ) {
	    	    			System.out.println(read[j][i]);
				    	}
		     		}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
                                     
 		/* DO NOT CLOSE  the streams and the socket connection here! 
                   Reason: The event handler will be invoked many times! 
	           - cf the onStop() method */
				    
//				String[][] test = new String[][]{{"hi"}};
		return read;
				
		} // end doInBackground
		@Override
	    protected void onPostExecute(String[][] reads) {
	        // The results of the above method
	        // Processing the results here
			try {
				names = new String[reads.length];
				
				for(int i = 0; i< reads.length ; i++){
					names[i] = reads[i][1];
				}
			} catch (NullPointerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

    }// end class

}
