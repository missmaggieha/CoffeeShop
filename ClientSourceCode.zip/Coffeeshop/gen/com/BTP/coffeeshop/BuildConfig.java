/** Automatically generated file. DO NOT MODIFY */
package com.BTP.coffeeshop;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}